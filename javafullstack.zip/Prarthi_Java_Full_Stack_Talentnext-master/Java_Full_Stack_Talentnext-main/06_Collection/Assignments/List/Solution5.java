import java.util.LinkedList;

/*
 * Implement the assignment 1 using Linked List 
 */
public class Solution5 {
    public static void main(String[] args) {
        LinkedList<String> months = new LinkedList<>();
        months.add("Jan");
        months.add("Feb");
        months.add("March");
        months.add("April");
        months.add("May");
        months.add("June");
        months.add("July");
        months.add("Aug");
        months.add("Sep");
        months.add("Oct");
        months.add("Nov");
        months.add("Dec");

        System.out.println(months);
    }
}