package abstraction_packages_exception_handling.miniproject.com.mile1.service;

import abstraction_packages_exception_handling.miniproject.com.mile1.bean.Student;

public class StudentService {
    // method 
    // This method is used to count the number of objects
    // where the marks array is null 
    public int findNumberOfNullMarksArray ( Student s[] )
    {
        try {

        } 
        catch(NullPointerException e ) {

        }
        return 0;
    }    

    public int findNumberOfNullName( Student s[] )
    {
        try {

        } 
        catch(NullPointerException e ) {

        }
        return 0;   
    }

    public int findNumberOfNullObjects ( Student s[] ) 
    {
        try {

        } 
        catch(NullPointerException e ) {

        }
        return 0;
        
    }

}




