package abstraction_packages_exception_handling.miniproject.com.mile1.exception;

public class NullMarksArrayException  extends Exception {
    @Override
    public String toString() {
        return "mark array is null" ;
    }
}
