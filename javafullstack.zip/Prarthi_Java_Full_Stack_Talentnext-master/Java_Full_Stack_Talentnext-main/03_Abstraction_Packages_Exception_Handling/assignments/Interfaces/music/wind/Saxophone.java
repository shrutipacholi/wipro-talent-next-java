package abstraction_packages_exception_handling.assignments.interfaces.music.wind;
import abstraction_packages_exception_handling.assignments.interfaces.music.Playable;


public class Saxophone implements Playable {
    
    public void play() 
    {
        System.out.println("Playing Saxophone");
    }
}
