package abstraction_packages_exception_handling.assignments.interfaces.music.string;

import abstraction_packages_exception_handling.assignments.interfaces.music.Playable;

public class Veena implements Playable {
    
    public void play() 
    {   
        System.out.println("Playing Veena");
    }
}
