// Vehicle.java
package abstraction_packages_exception_handling.assignments.packages.solution4.com.automobile;

public abstract class Vehicle {
    public abstract String getModelName();
    public abstract String getRegistrationNumber();
    public abstract String getOwnerName();
}
