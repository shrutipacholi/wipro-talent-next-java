SELECT employee_id, last_name, job_id, hire_date as start_date 
FROM employees;

