SELECT employee_id  “Emp #”, last_name “Employee”, job_id “Job”, hire_date “Hire Date”
FROM employees;
