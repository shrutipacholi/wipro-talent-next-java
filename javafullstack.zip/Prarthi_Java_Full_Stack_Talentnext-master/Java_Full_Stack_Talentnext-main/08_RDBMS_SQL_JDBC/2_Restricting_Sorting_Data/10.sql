SELECT last_name, salary
FROM employees
WHERE salary> &salary;
