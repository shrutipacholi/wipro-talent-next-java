SELECT last_name, hire_date
FROM employees
WHERE hire_date  LIKE  ’%1994’;
