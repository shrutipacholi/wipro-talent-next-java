UPDATE MY_EMPLOYEE
SET salary = salary + (salary* 0.1)
WHERE department_id = 90;
