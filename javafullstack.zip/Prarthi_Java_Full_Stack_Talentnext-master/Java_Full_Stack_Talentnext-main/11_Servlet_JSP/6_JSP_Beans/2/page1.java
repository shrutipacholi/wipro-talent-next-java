import java.io.Serializable;

public class Page1 implements Serializable{
    private int num;
    public void setNum(int num) {
        this.num=num;
    }
    
    public int getNum() {
        return num;
    }
}
